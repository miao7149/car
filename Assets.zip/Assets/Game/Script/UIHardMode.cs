using System.Collections;
using System.Collections.Generic;
using SuperScrollView;
using UnityEngine;
public class HardItemData
{
    public string mLevelID;
    //解锁关卡数
    public int mUnlockLevelCount;
}
public class UIHardMode : MonoBehaviour
{
    public LoopGridView mLoopGridView;
    private List<HardItemData> hardItems = new List<HardItemData>();
    public GameObject m_HardModeRoot;
    void Start()
    {
        hardItems.Add(new HardItemData
        {
            mLevelID = "1",
            mUnlockLevelCount = 16,
        });
        hardItems.Add(new HardItemData
        {
            mLevelID = "2",
            mUnlockLevelCount = 20,
        });
        hardItems.Add(new HardItemData
        {
            mLevelID = "3",
            mUnlockLevelCount = 25,
        });
        // 初始化数据
        for (int i = 0; i < 267; i++)
        {
            hardItems.Add(new HardItemData
            {
                mLevelID = (i + 4).ToString(),
                mUnlockLevelCount = 25 + (i + 1) * 10,
            });
        }
        // 设置列表项数量
        // mLoopGridView.Padding.left = (Screen.width - 960) / 2;
        mLoopGridView.InitGridView(hardItems.Count, OnGetItemByRowColumn);
    }

    LoopGridViewItem OnGetItemByRowColumn(LoopGridView gridView, int index, int row, int column)
    {
        if (index < 0)
        {
            return null;
        }


        LoopGridViewItem item = null;

        //get the data to showing
        HardItemData itemData = hardItems[index];
        if (itemData == null)
        {
            return null;
        }
        item = gridView.NewListViewItem("HardItem");
        var itemScript = item.GetComponent<HardItem>();
        itemScript.SetItemData(itemData);
        itemScript.Init();
        return item;
    }
    public void OnCloseBtnClicked()
    {
        m_HardModeRoot.SetActive(false);
    }
    public void OnHardModeBtn()
    {
        m_HardModeRoot.SetActive(true);
    }
}
